<?php

if(!defined("ROOT")){ define("ROOT", $_SERVER['DOCUMENT_ROOT']); }

include_once(ROOT ."/app/controller/required.php");

/* check if user loggedin, */
$upload_dir = 'public/';

if(isset($usersession) AND $usersession->isLogin()){

	$ulink = encodeString($usersession->info()->id, $encryptKey) .'/';

	if(file_exists(ROOT ."/uploads/". $ulink)){
		$upload_dir = $ulink;
	} else {
		if(mkdir(ROOT ."/uploads/". $ulink)){
			fopen(ROOT ."/uploads/". $ulink ."/index.html", 'w');
			$upload_dir = $ulink;
		}
	}

}

/** Full path to the folder that images will be used as library and upload. Include trailing slash */
define('LIBRARY_FOLDER_PATH', ROOT .'/uploads/'. $upload_dir);

/** Full URL to the folder that images will be used as library and upload. Include trailing slash and protocol (i.e. http://) */
define('LIBRARY_FOLDER_URL', 'http://'. $_SERVER['HTTP_HOST'] .'/uploads/'. $upload_dir);

/** The extensions for to use in validation */
define('ALLOWED_IMG_EXTENSIONS', 'gif,jpg,jpeg,png,jpe');

/**  Use these 3 functions to check cookies and sessions for permission. 
Simply write your code and return true or false */


function CanAcessLibrary(){
	return true;
}

function CanAcessUploadForm(){
	return true;
}

function CanAcessAllRecent(){
	return false;
}

function CanCreateFolders(){
	global $usersession;
	return $usersession->isLogin();
}

function CanDeleteFiles(){
	global $usersession;
	return $usersession->isLogin();
}

function CanDeleteFolder(){
	global $usersession;
	return $usersession->isLogin();
}

function CanRenameFiles(){
	return true;
}

function CanRenameFolder(){
	global $usersession;
	return $usersession->isLogin();
}
